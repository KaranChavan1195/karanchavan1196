CREATE TABLE Salesman
(
	SalesmanID int PRIMARY KEY,
	SalesmanName varchar(20),
	ContactNo bigint
)
create procedure AddSalesman
(
	@SalesmanID int,
	@SalesmanName varchar(20),
	@ContactNo bigint
)
As
INSERT INTO Salesman
VALUES(@SalesmanID,@SalesmanName,@ContactNo)

EXEC  AddSalesman 101,'Nikhil Kundu',9594882088

CREATE PROCEDURE udp_getsalesman
AS
SELECT * FROM Salesman

EXEC udp_getemployee

CREATE PROCEDURE RetrieveSalesmanInfo
(
	@SalesmanID int
)
AS
SELECT * FROM Salesman
WHERE SalesmanID=@SalesmanID

EXEC RetrieveSalesmanInfo 101

CREATE PROCEDURE udp_deletesalesman
(
	@SalesmanID int
)
AS
DELETE FROM Salesman
WHERE SalesmanID=@SalesmanID


CREATE PROCEDURE udp_updatesalesman
(
	@SalesmanID int,
	@SalesmanName varchar(20),
	@ContactNo bigint
)
AS
Update Salesman
Set SalesmanName=@SalesmanName,ContactNo=@ContactNo
Where SalesmanID=@SalesmanID

SELECT * FROM Salesman

EXEC udp_updateemployee 100,'Nikhil Kundu',9220994257