﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
using SMS.Excepetion;
using SMS.Entity;
using SMS.DAL;


namespace SMS.BL
{
    public class SalesmanValidation
    {
        SalesmanOperation operationobj = new SalesmanOperation();

         public bool ValidateSalesman(Salesman salObj)
        {
            bool validSalesman= true;
            StringBuilder sb = new StringBuilder();
            if (salObj.SalesmanID.ToString().Length == 0)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman ID is required.");
            }
            if (salObj.SalesmanName.Length == 0)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman Name is required.");
            }
            if (salObj.ContactNo.ToString().Length == 0)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman Contact No is required.");
            }
            if (!(Regex.IsMatch(salObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman ID should contain only numbers.");
            }
            if (!(Regex.IsMatch(salObj.SalesmanName, @"^[a-zA-Z ]+$")))
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Salesman Name should contain only characters.");
            }
            if (!(Regex.IsMatch(salObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            }
            if (salObj.ContactNo.ToString().Length != 10)
            {
                validSalesman = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }
            if (validSalesman == false)
                throw new SalesmanException(sb.ToString());
            return validSalesman;
        }

           public bool AddSalesmanRecord(Salesman salObj)
        {
            bool salAdded = false;
            if (ValidateSalesman(salObj))
                salAdded = operationobj.AddSalesmanRecord(salObj);
            return salAdded;
        }
           public DataTable GetSalesmanRecord(int salID)
        {

            DataTable salesmanTable = operationobj.GetSalesmanRecord(salID);
            return salesmanTable;
        }
          public DataTable GetAllSalesmanRecord()
        {
      
            try
            {
                DataTable salesmanTable = operationobj.GetAllSalesmanRecord();
                return salesmanTable;
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
       
        }
          public bool UpdateSalesman(Salesman salObj)
        {
            bool salupdate = false;
            try
            {
                if (ValidateSalesman(salObj))
                {
                    SalesmanOperation operationobj = new SalesmanOperation();
                    salupdate = operationobj.UpdateSalesmanSalesman(salObj);
                }
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            return salupdate;
        }
            public bool DeleteSalesmanSalesman(int salID)
        {
            bool saldelete = false;

            try
            {
                if (salID > 0)
                {
                    SalesmanOperation operationobj = new SalesmanOperation();
                    saldelete = operationobj.DeleteSalesmanSalesman(salID);
                }
                else
                {
                    throw new SalesmanException("Invalid ID");
                }
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

            return saldelete;
        }
    }
}

    

