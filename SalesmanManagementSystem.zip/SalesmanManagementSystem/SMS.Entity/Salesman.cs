﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    public class Salesman
    {
        // Property to store and retrieve salesmanID
        public int SalesmanID { get; set; }

        // Property to store and retrieve salesmanName
        public string SalesmanName { get; set; }

        // Property to store and retrieve salesmanContactNo

        public long ContactNo { get; set; }
    }
}
