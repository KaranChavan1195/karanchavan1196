﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SMS.Entity;
using SMS.Excepetion;
using System.Data;
using System.Data.SqlClient;
using SMS.BL;

namespace SMS.PL
{
    public partial class Form1 : Form
    {
        SalesmanValidation validationsObj = new SalesmanValidation();

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Salesman salObj = new Salesman();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    salObj.SalesmanID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Salesman ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                salObj.SalesmanName = txtName.Text;
                isNumber = long.TryParse(txtContact.Text, out contactNo);
                if (isNumber)
                    salObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool salAdded = validationsObj.AddSalesmanRecord(salObj);
                if (salAdded)
                    MessageBox.Show("Salesman Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add Salesman record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (SalesmanException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
             DataTable salesmanTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtID.Text, out result);
            if (isNumber)
                salesmanTable = validationsObj.GetSalesmanRecord(result);
            else
            {
                MessageBox.Show("Please enter only numbers in Salesman ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dataGridView1.DataSource= salesmanTable;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
              try
            {
                Salesman salupdate = new Salesman();
                salupdate.SalesmanID = Convert.ToInt32(txtID.Text);
                salupdate.SalesmanName = txtName.Text;
                salupdate.ContactNo = Convert.ToInt64(txtContact.Text);


                bool status = validationsObj.UpdateSalesman(salupdate);

                if (status)
                {
                    MessageBox.Show("Salesman Details Updated");
                    DataTable salesmanTable = validationsObj.GetAllSalesmanRecord();
                }
                else
                {
                    MessageBox.Show("Unable to Update Salesman Detail");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
             try
            {
                int salid = Convert.ToInt32(txtID.Text);
                bool status = validationsObj.DeleteSalesmanSalesman(salid);

                if (status)
                {
                    MessageBox.Show("Salesman Deleted");
                    DataTable salesmanTable = validationsObj.GetAllSalesmanRecord();
                }
                else
                {
                    MessageBox.Show("Unable to delete Salesman Details");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DataTable salesmanTable = new DataTable();

            salesmanTable = validationsObj.GetAllSalesmanRecord();

            dataGridView1.DataSource = salesmanTable;
        }
        
    }
}
     


        