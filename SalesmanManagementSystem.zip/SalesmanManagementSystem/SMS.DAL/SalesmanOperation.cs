﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using SMS.Entity;
using SMS.Excepetion;
using System.Data.SqlClient;
using System.Configuration;

namespace SMS.DAL
{
    public class SalesmanOperation
    {
        SqlConnection connection;
        SqlDataReader reader;
    
      public SalesmanOperation()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["salconn"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
         public bool AddSalesmanRecord(Salesman salObj)
        {
            try
            {
                bool salAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddSalesman", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@SalesmanID", salObj.SalesmanID);
                cmdAdd.Parameters.AddWithValue("@SalesmanName", salObj.SalesmanName);
                cmdAdd.Parameters.AddWithValue("@ContactNo", salObj.ContactNo);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    salAdded = true;
                return salAdded;
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
                public DataTable GetSalesmanRecord(int salID)
        {
            SqlCommand cmdGetSalesman = new SqlCommand("RetrieveSalesmanInfo", connection);
            cmdGetSalesman.CommandType = CommandType.StoredProcedure;
            cmdGetSalesman.Parameters.AddWithValue("@SalesmanID", salID);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            reader = cmdGetSalesman.ExecuteReader();
            DataTable salesmanTable = new DataTable();
            salesmanTable.Load(reader);
            return salesmanTable;
        }
          public DataTable GetAllSalesmanRecord()
        {
            
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_getsalesman";
                cmd.Connection = connection;
                if (connection.State == ConnectionState.Closed)

                    connection.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                DataTable salesmanTable = new DataTable();
                salesmanTable.Load(dr);
               
                return salesmanTable;
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }
           public bool UpdateSalesmanSalesman(Salesman salObj)
        {
            bool salupdate = false;

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_updatesalesman";
                cmd.Parameters.AddWithValue("@SalesmanID", salObj.SalesmanID);
                cmd.Parameters.AddWithValue("@SalesmanName", salObj.SalesmanName);
                cmd.Parameters.AddWithValue("@ContactNo", salObj.ContactNo);
                cmd.Connection = connection;
                if (connection.State == ConnectionState.Closed)
                connection.Open();

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    salupdate = true;
                return salupdate;
            }

            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
         public bool DeleteSalesmanSalesman(int salID)
        {
            bool saldelete = false;
            try
            {
              SqlCommand  cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_deletesalesman";
                cmd.Parameters.AddWithValue("@SalesmanID", salID);
                cmd.Connection = connection;
                if (connection.State == ConnectionState.Closed)
                connection.Open();
           

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    saldelete = true;
                return saldelete;
            }
            catch (SalesmanException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
          
        }
    }
}




