﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Excepetion
{
    public class SalesmanException : ApplicationException
    {
         // default constructor 
        public SalesmanException() 
           : base()
        { }

        //parameterized constructor
        public SalesmanException(string message) 
             : base(message)
        { }
    }
}
